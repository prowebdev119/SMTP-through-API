<?php

//Detch

//index 
    $lang['main_text'] = 'Ticket Portal';
    $lang['left_blck_title'] = "NEW TICKET E-Mail";
    $lang['right_blck_title'] = "NEUES TICKET ERSTELLEN";
    $lang['footer_3'] = "Ticket Statusabfrage";
    $lang['popup_header'] = "Neues Ticket erstellen";
    $lang['email_add'] = "Email-Adresse";
    $lang['row_2'] = "Priorität";
    $lang['pop_title'] = "Betreff";
    $lang['pop_text'] = "Beschreibung";
    $lang['file_upload'] = "Datei hochladen";
    $lang['send'] = "Erstellen";
    $lang['close'] = "Abbrechen";

    $lang['first_name'] = "First name";
    $lang['last_name'] = "Last name";
    $lang['ticket_impact'] = "Impact";
    $lang['ticket_type'] = "Type";

?>