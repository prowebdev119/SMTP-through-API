<?php

//French

//index 
    $lang['main_text'] = 'Portail de billets';
    $lang['left_blck_title'] = "NEW TICKET E-Mail";
    $lang['right_blck_title'] = "CRÉER UN NOUVEAU BILLET";
    $lang['footer_3'] = "Requête sur l'état du ticket";
    $lang['popup_header'] = "Créer un nouveau billet";
    $lang['email_add'] = "Adresse e-mail";
    $lang['row_2'] = "Priorité";
    $lang['pop_title'] = "Concernant";
    $lang['pop_text'] = "La description";
    $lang['file_upload'] = "Téléverser un fichier";
    $lang['send'] = "Créer";
    $lang['close'] = "Avorter";

    $lang['first_name'] = "First name";
    $lang['last_name'] = "Last name";
    $lang['ticket_impact'] = "Impact";
    $lang['ticket_type'] = "Type";

?>