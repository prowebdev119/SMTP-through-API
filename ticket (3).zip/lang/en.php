<?php

//English

//index 
    $lang['main_text'] = 'Ticket portal';
    $lang['left_blck_title'] = "NEW TICKET E-Mail";
    $lang['right_blck_title'] = "CREATE A NEW TICKET";
    $lang['footer_3'] = "Ticket status query";
    $lang['popup_header'] = "Create A NEW TICKET";
    $lang['email_add'] = "E-mail address";
    $lang['row_2'] = "Priority";
    $lang['pop_title'] = "Regarding";
    $lang['pop_text'] = "Description";
    $lang['file_upload'] = "Upload file";
    $lang['send'] = "Create";
    $lang['close'] = "Abort";

    $lang['first_name'] = "First name";
    $lang['last_name'] = "Last name";
    $lang['ticket_impact'] = "Impact";
    $lang['ticket_type'] = "Type";

?>