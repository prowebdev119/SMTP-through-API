<?php
//API Info
define('API_URL', 'https://app.atera.com/api/v3/'); // Ticket API URL
define('API_KEY', '63ca0f565c5d417dbccbde87a923ed67'); // Ticket API Key
define('DeviceGuid', ''); // DeviceGuid
//-- SMTP SERVER Info
define('SMTP_SERVER', 'bsmtp.A1.net');
define('SMTP_USER', 'ticketsys@onemaksys.com');
define('SMTP_PASSWORD', 'iGiO&vBWQ2');
define('SMTP_PORT', '587');

